﻿namespace DavidToveyTestProject.Models
{
    public class Subjects
    {
        //<summary>
        //Unique identifier for Subject
        //</summary>
        public int Id { get; set; }

        //<summary>
        //Subject Name
        //</summary>
        public string Subject { get; set; }
    }
}
