﻿namespace DavidToveyTestProject.Models
{
    public class DetailsViewModel
    {
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Telephone { get; set; }
    }
}
